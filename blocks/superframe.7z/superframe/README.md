 Copyright  Daniel Neis <danielneis@gmail.com>

 Modified for use in MoodleBites for Developers Level 1
 by Richard Jones & Justin Hunt.

 See: https://www.moodlebites.com/mod/page/view.php?id=24546

 Cloned from newblock.